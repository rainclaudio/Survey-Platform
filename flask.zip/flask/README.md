# Comandos para poder ejecutarlo

1. lo primero es tener python y pip (verificar escribiendolo en la cmd)
2. pip install flask (verificar: type python, then type import flask, no error displayed)

Opción alternativa, instalar todo con : pip install -r requirements.txt
## flask wtf: extensión que nos ayuda a crear forms

1. instalación: pip install flask-wtf y luego pip install email-validator

## sql alchemy

1. instalación: pip install flask-sqlalchemy
