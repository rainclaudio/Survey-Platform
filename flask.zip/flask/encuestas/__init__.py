from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager
app = Flask(__name__)
app.config['SECRET_KEY'] = '5791628bb0b13ce0c676dfde280ba245'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.jinja_env.filters['zip'] = zip  # AGREGADO POR MATIAS.
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager_ = LoginManager(app)
login_manager_.login_view = 'login'
login_manager_.login_message_category = 'info'
#Comentario grande

from encuestas import routes