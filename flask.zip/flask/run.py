from encuestas import app


#python run.py
if __name__ == '__main__':
	app.run(debug=True)
